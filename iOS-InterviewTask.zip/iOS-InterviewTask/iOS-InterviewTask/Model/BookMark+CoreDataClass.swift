//
//  BookMark+CoreDataClass.swift
//  iOS-InterviewTask
//
//  Created by Md. Faysal Ahmed on 21/2/23.
//
//

import Foundation
import CoreData


public class BookMark: NSManagedObject {

}
